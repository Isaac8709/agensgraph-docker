/* pg_cron--0.1--1.0.sql */

SELECT pg_catalog.pg_extension_config_dump('cron.job', '');
